    // basic syntax and output
    console.log('hello welcome to javascript');
    // Question 2: JavaScript Display Possibilities
    console.log('hello ali');
    alert("your website is control in hacker hand");
    document.write('hello Asad');
    // Question 3: Variables and Restrictions
   const name="Faizan";
   const age= '14';
   console.log('age'==name);
   console.log('name'==age);

// Define the numbers
let num1 = 10;
let num2 = 5;

// Question 4: Arithmetic Operators
let sum=12+12;
console.log(sum);
let minus=12-12;
console.log(minus);
let multiply=12*12;
console.log(multiply);
let divide=14/14;
console.log(divide);
// Question 5: Comparison Operators
let num4=5;
num5=10;
console.log(num4==num5);
console.log(num4===num5);
console.log(num4!=num5);
console.log(num4!==num5);
console.log(num4>num5);
console.log(num4<num5);
console.log(num4<=num5);
console.log(num4>=num5);

// Question 7: Logical Operators
let num=5;
num=num>10 && num<50;;
console.log(num);
let num6=10;
num6=num6!=10;
console.log(num6);
let num7=10;
num7=num7==10||num7!=10;
console.log(num7);
// Question 8: Basic Arithmetic Expression
let result1=8*2;
let result2=result1+6;
let finalresult=result2-3;
console.log(finalresult);
// Question 9: Combining Operators
let result3=15/3;
let result4=7-2;
let finalresults=result3*result4;
console.log(finalresults)
// Question 10: Complex Expression
let result5=9+5 ;
let result6=12/4*result5;
let finalresultss=result6-7;
console.log(finalresultss);
// Question 11: Nested Expressions
result7=20-4;
result8=result7 /2;
result9=result8+6*3;
console.log(result9);
// Question 12: Mixed Operations
let result10=25/(5-3);
let result11=(4+6)*2
let result12=result10+result11
console.log(result12)