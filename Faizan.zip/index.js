// if else question
// . Check if a number is positive or negative
// Write a JavaScript program that prompts the user to enter a number and checks if it's 
// positive, negative, or zero.

let num = 4
if (num > 0) {
    console.log(" postive number")
}
else if (num < 0) {
    console.log("negative number")
}
else {
    console.log("zero")
}
//. Check if a number is within a range
// Write a JavaScript program that prompts the user to enter a number and checks if it is 
// between 10 and 20(inclusive).Display the appropriate message.
let num1 = 2
if (num1 <= 2 && num1 >= 1) {
    console.log("within range")
}
else {
    console.log("outside range")
}
// Check if two numbers are equal
// Write a JavaScript program that prompts the user to enter two numbers and checks if 
// they are equal. If they are not, display "The numbers are different."a
let num2 = 23
if (num2 <= 22 && num2 >= 21) {
    console.log("they are equal")
}
else {
    console.log("the numbers are different")
}
// . Check if a person is eligible to vote
// Write a JavaScript program that prompts the user to enter their age and checks if they 
// are eligible to vote (age 18 or more).
let age = 18;
if (age >= 18) {
    console.log("Eligible to vote");
} else {
    console.log("Not eligible to vote");
}
// Check which number is greater
// Write a JavaScript program that prompts the user to enter two numbers and displays 
// the greater one. If they are equal, display "Both numbers are equal."
let num3 = 2
let num4 = 3
if (num4 > num3) {
    console.log("the number is greater")
}
else {
    console.log("Both number are equal")
}
// Check if a number is a multiple of 5
// Write a JavaScript program that prompts the user to enter a number and checks if it is 
// a multiple of 5. Display the appropriate message.
let num5 = 4
if (num5 * 5 == 20) {
    alert(num5 + " is a multiple of 5.");
} else {
    alert(num5 + " is not a multiple of 5.");
}
// Check if a year is a leap year
// Write a JavaScript program that prompts the user to enter a year and checks if it is a 
// leap year. Display the result in the console.
let year = 2
if (year >>= 1 && year <= 1) {
    console.log("leap year")
}
else {
    console.log("not a leap year")

}
// Compare three numbers
// Write a JavaScript program that prompts the user to enter three numbers and checks 
// which one is the largest
let num6 = 3
let num7 = 13
let num8 = 19
if (num6 < num7 && num7 > num8) {
    console.log(num6 + " is the largest")

}
else if (num7 < num8 && num8 > num7) {
    console.log(num7 + " is the largest")

}
else if (num8 < num7 && num8 > num6) {
    console.log(num8 + " is the largest")

}
// check eligibility for a senior citizen discount
// Write a JavaScript program that prompts the user to enter their age and checks if they 
// are eligible for a senior citizen discount (age 60 or above).
let side1 = 2
let side2 = 5
let side3 = 3
if (side1 + side2 > side3 && side2 + side3 > side1) {
    console.log("vaild triangle")
}
else (
    console.log("invaild triangle")
)
// . Print numbers from 1 to a given number
// Write a JavaScript program that prompts the user to enter a number and prints all the 
// numbers from 1 up to the entered number using a while loop
let iv = 1
let num9 = prompt("Enter a number")
while (iv <= num9) {
    console.log(iv); iv++
}
// Print even numbers between 1 and a given number
// Write a JavaScript program that prompts the user to enter a number and prints all even 
// numbers between 1 and that number using a while loop.
let x = 2
while (x <= 10) {
    console.log(x, "even number"); x += 2
}
// write a JavaScript program that prompts the user to enter a number and calculates the 
// sum of the first N natural numbers using a while loop.
// let nums=parseInt(prompt("Enter any natural number"));
let nums12 = prompt("Enter a natural number")
let sum = 0
let i = 1
while (i <= nums12) {
    sum = sum + i, i++
}
console.log("sum of natural number" + sum)

// . Factorial of a number
// Write a JavaScript program that prompts the user to enter a number and calculates its 
// factorial using a while loop
let numbers =(prompt("Enter any  number"))
let sum1 = 1
let f = 1
while (f <= numbers) {
    sum1 = sum1 * f, f++
}
console.log("factorial is :" + sum1)
// Print numbers in reverse order
// Write a JavaScript program that prompts the user to enter a number and prints all 
// numbers from that number down to 1 using a while loop
let c = 1
let num10 = prompt("Enter a number for reverse")
while (c <= num10) {
    console.log(num10, "reverse order"); num10--
}
// . Prompt for input until a valid number is entered
// Write a JavaScript program that keeps prompting the user for input until they enter a 
// valid number using a while loop
let fc = prompt("Enter a number greater than 0 and less than 51 and enter on first chance sceond chance no collect a number")

while (fc > 50) {
    prompt("Invaid,Enter a number")


}
// . Print multiplication table of a given number
// Write a JavaScript program that prompts the user to enter a number and prints its 
// multiplication table up to 10 using a while loop.
let nums = prompt("Enter a number")
let e = 1
while (e <= 10) {
    console.log("tabel 1 to start 10", nums * e,); e++
}
// Sum of digits of a number
// Write a JavaScript program that prompts the user to enter a number and calculates the 
// sum of its digits using a while loop.

let z = parseInt(prompt("Enter a three digit"))
let sum6 = 0
while (z > 0) {
    sum6 += z % 10
    z = parseInt(z / 10)
}
console.log("sum of digit number" + sum6)
// . Print odd numbers between tw
// Write a JavaScript program that prompts the user to enter two numbers and prints all
// odd numbers between them using a while loop.

let y = 1
while (y <= 15) {
    console.log(y, "odd number"); y = y + 2
}
// 10. Count digits in a number
// Write a JavaScript program that prompts the user to enter a number and uses a while
// loop to count how many digits the number has.
// Prompt the user to enter a number
let digits=0
while(digits<=number){
    number=number/10;
    digits++
}
console.log("The number of digit"+digits)
// For Loop Questions:
// 1. Print numbers from 1 to a given number
// Write a JavaScript program that prompts the user to enter a number and prints all 
// numbers from 1 to the entered number using a for loop
let prompts=prompt("Enter a number")
for (let p = 1; p <= prompts; p++) {
    console.log("for lop number print" + p)
}
// print even numbers between 1 and a given number
// Write a JavaScript program that prompts the user to enter a number and prints all even 
// numbers between 1 and that number using a for loop
let prompt2=prompt("Enter a njumber")
for (let q = 2; q <= prompt2; q = q = q + 2) {
    console.log("for lop even number print" + q)

}
// Calculate the sum of first N natural numbers
// Write a JavaScript program that prompts the user to enter a number and calculates the 
// sum of the first N natural numbers using a for loop.
let numss = prompt("Enter this number")
let sums15 = 0
for (let t = 1; t <= numss; t++) {
    sums15 = sums15 + t
}
console.log(sums15)
// Print the multiplication table of a given number
// Write a JavaScript program that prompts the user to enter a number and prints its 
// multiplication table up to 10 using a for loop
let nums17 = prompt("Enter a number for tabel")
for (let n = 1; n <= 10; n++) {
    console.log("for loop multiplication", n * nums17)

}
// 5. Print the reverse of a given number
// Write a JavaScript program that prompts the user to enter a number and prints its 
// digits in reverse order using a for loop.
let m = prompt("enter a  number to reverse order")
for (let n = 100; n >= m; n = n - 1) {
    console.log(n, "reverse for loop digit")
}
// Find the factorial of a number
// Write a JavaScript program that prompts the user to enter a number and calculates its 
// factorial using a for loop.
let g = prompt("Enter a  number to factorial")
let sumss = 1
for (let b = 1; b <= g; b++) {
    sumss = sumss * b
    console.log("for loop factorial", sumss)
}
// 7. Print a pattern of stars
// Write a JavaScript program that prompts the user to enter a number and prints a
//  rightangled triangle pattern of stars using a for loop 

var rows=parseInt(prompt("Enter a row"))
for(var s=1;s<=rows;s++){
    var pattern=""
 for(var j=1;j<=s;j++){
    pattern+="*"
 }
  console.log(pattern);

}
// 8. Sum the digits of a number
// Write a JavaScript program that prompts the user to enter a number and calculates the 
// sum of its digits using a for loop.
let asad = parseInt(prompt("Enter a three digit"))
for (let sum9=0;asad >sum9;) {
    sum9 += asad % 10
    asad = (asad / 10)
console.log("sum of digit number" + sum9)

}
// Print all prime numbers up to a given number
// Write a JavaScript program that prompts the user to enter a number and prints all 
// prime numbers up to that number using a for loop
let promot=prompt("enter  anumber")
for(let z=1;z<=8;z=z+2){
console.log("prime number 1 to 8",z)

}


// 10. Count occurrences of a digit in a number
// Write a JavaScript program that prompts the user to enter a number and a digit, and 
// then counts how many times the digit appears in the number using a for loop.

var numsss=prompt("Enter a number")
var digit=prompt("Enter a digit")
var counting=1

for(var ics=0;ics<=numsss;ics++){
    if(numsss==digit){
        counting++
    }
}
console.log("The digit"+digit+"appear"+counting+"time in"+numsss)